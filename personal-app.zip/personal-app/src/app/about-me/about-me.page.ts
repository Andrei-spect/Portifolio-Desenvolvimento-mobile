import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-about-me',
  templateUrl: './about-me.page.html',
  styleUrls: ['./about-me.page.scss'],
})
export class AboutMePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
