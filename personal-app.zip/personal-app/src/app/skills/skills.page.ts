import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-skills',
  templateUrl: './skills.page.html',
  styleUrls: ['./skills.page.scss'],
})
export class SkillsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
