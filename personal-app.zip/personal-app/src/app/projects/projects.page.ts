import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-projects',
  templateUrl: './projects.page.html',
  styleUrls: ['./projects.page.scss'],
})
export class ProjectsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
