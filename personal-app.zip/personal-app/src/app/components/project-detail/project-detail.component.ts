import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.scss'],
})
export class ProjectDetailComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
